﻿namespace PokemonParticipation
{
    internal class ResultObject
    {
        public string name { get; set; }
        public string url { get; set; }
        public string front_default { get; set; }
        public double height { get; set; }
        public double weight { get; set; }
    }
}